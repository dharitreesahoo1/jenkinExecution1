package Strings;

public class ConvertNumberToString {

	public static void main(String[] args) {
		int a = 8;
		String a1 = Integer.toString(a);
		//Covert integer to string
		System.out.println(a1);
		//Convert String to Integer
		String str = "2";
		Integer b1 = Integer.valueOf(str);
		System.out.println(b1);

	}

}
