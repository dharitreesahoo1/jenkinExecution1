package Strings;

public class RemoveAllwhiteSpaceFromString {

	public static void main(String[] args) {
		String str = "This is my home";
		String ExpectedStr = str.replace(" ", "");
		System.out.println(ExpectedStr);
		

	}

}
