package Strings;

public class CountNoOfWordsInString {

	public static void main(String[] args) {
		String str= "Dharitree sahoo";
		String[] arr = str.split(" ");
		System.out.println(arr.length);

	}

}
