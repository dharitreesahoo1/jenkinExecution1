package Collections;

import java.util.HashMap;
import java.util.Map;

public class HashMapWithObject {
	public static Map<Integer, Employee> createMap()
	{
		Map<Integer,Employee>hashMap =  new HashMap<>();
		Employee e1 =  new Employee(1, "Dhaitree1");
		Employee e2 =  new Employee(2, "Dhaitree2");
		Employee e3 =  new Employee(3, "Dhaitree3");
		Employee e4 =  new Employee(4, "Dhaitree4");
		hashMap.put(e1.EmpId,e1);
		hashMap.put(e2.EmpId,e2);
		hashMap.put(e3.EmpId,e3);
		hashMap.put(e4.EmpId,e4);
		return hashMap;
	}

	public static void main(String[] args) {
		
		Map<Integer, Employee> map = createMap();
		for(Integer key:map.keySet())
		{
			Employee emp = map.get(key);
			System.out.println(emp.EmpName);
		}

	}

}
