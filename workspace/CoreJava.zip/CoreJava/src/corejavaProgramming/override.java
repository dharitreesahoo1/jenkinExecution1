package corejavaProgramming;

public @interface override {

}
